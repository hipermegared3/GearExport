===============================================================================
GEAR EXPORT ADDON - GUÍA DE USO E INSTALACIÓN
===============================================================================

Nombre del Addon: GearExport
Versión: 1.1.0
Autor / Creador: Cobralive (Warmane - WotLK 3.3.5a)
Compatibilidad: World of Warcraft: Wrath of the Lich King (3.3.5a)

-------------------------------------------------------------------------------
1. ¿QUÉ ES GEAR EXPORT Y PARA QUÉ SIRVE? (ESPAÑOL)
-------------------------------------------------------------------------------
GearExport es una herramienta ligera creada especialmente para jugadores que 
buscan optimizar el rendimiento de su personaje (DPS, Tanque o Sanador) 
utilizando Inteligencia Artificial (ChatGPT, Gemini, Claude, etc.).

Al hacer clic en el botón "Exportar Equipo" dentro del juego, el addon escanea 
y genera de forma automática un informe detallado que incluye:
  - Información de tu personaje (Nombre, Raza, Clase y Especialización).
  - TUS GLIFOS (Sublimes y Menores equipados).
  - ESTADÍSTICAS GLOBALES completas (Atributos base, Melee, A distancia, 
    Hechizos y Defensa/Supervivencia con índices de Golpe, Crítico, Pericia, etc.).
  - REGISTRO DETALLADO DE TU EQUIPO: Cada pieza equipada con sus estadísticas, 
    gemas encajadas, encantamientos y enlaces interactivos.
  - PIEZAS DE EQUIPO DISPONIBLES EN BOLSAS: Filtra y registra las piezas de tu 
    inventario (calidad rara o superior) para que la IA evalúe posibles reemplazos o mejoras.

El reporte incluye una solicitud estructurada al inicio para que simplemente 
copies el texto, se lo pegues a cualquier IA de tu preferencia y le preguntes:
  - ¿Voy por buen camino con mi equipo y estadísticas actuales?
  - ¿Tengo el índice de golpe (Hit) o pericia (Expertise) sobre-capados?
  - ¿Mis gemas y encantamientos son los óptimos para mi rol?
  - ¿Tengo alguna pieza en mis bolsas que sea mejor que la que llevo equipada?
  - ¿Qué piezas prioritarias debería buscar en mazmorras o bandas para mejorar?


-------------------------------------------------------------------------------
2. INSTRUCCIONES DE INSTALACIÓN
-------------------------------------------------------------------------------
Para instalar el addon desde este archivo .ZIP, sigue estos sencillos pasos:

Paso 1: Extrae el archivo .ZIP en tu computadora.
Paso 2: Abre tu carpeta de juego de World of Warcraft 3.3.5a.
Paso 3: Ve a la siguiente ruta dentro de tu carpeta del juego:
        WoW-3.3.5a/Interface/AddOns/

Paso 4: Copia o arrastra la carpeta llamada "GearExport" directamente dentro de 
        la carpeta "AddOns".
        
        La ruta final debe verse así:
        .../World of Warcraft/Interface/AddOns/GearExport/
          - GearExport.toc
          - GearExport.lua
          - LICENSE.txt
          - README.txt
          - CHANGELOG.txt

Paso 5: Entra al juego. En la pantalla de selección de personajes, haz clic 
        en el botón "Accesorios" (Addons) abajo a la izquierda y asegúrate 
        de que "GearExport" esté marcado y la opción "Cargar accesorios antiguos" 
        esté activada.

-------------------------------------------------------------------------------
3. CÓMO USAR EL ADDON EN EL JUEGO
-------------------------------------------------------------------------------
1. Entra con tu personaje al juego.
2. Tienes tres formas de acceder al exportador:
   a) Un botón flotante movible en la pantalla ("Exportar Equipo").
   b) Un icono en el Minimapa (pasa el cursor para ver el tooltip o haz clic directo).
   c) Un botón en la Ventana de Personaje ("Exportar IA") situado arriba a la derecha.
3. Haz clic en cualquiera de los botones (o escribe /gearexport o /ge en el chat).
4. Se abrirá una ventana con todo tu informe generado (verás la versión v1.1.0 abajo a la izquierda).
5. Haz clic dentro del recuadro de texto, presiona Ctrl + A (para seleccionar todo) 
   y luego Ctrl + C (para copiar).
6. Ve a tu Chat de Inteligencia Artificial preferido, presiona Ctrl + V (pegar) 
   y envía el mensaje. ¡Recibirás un análisis profesional al instante!

Nota: Si por alguna razón mueves el botón flotante fuera de la pantalla, escribe en el chat:
      /gearexport button
Esto centrará el botón nuevamente en el medio de tu interfaz.

===============================================================================


===============================================================================
GEAR EXPORT ADDON - USER & INSTALLATION GUIDE
===============================================================================

-------------------------------------------------------------------------------
1. WHAT IS GEAR EXPORT AND WHAT IS IT FOR? (ENGLISH)
-------------------------------------------------------------------------------
GearExport is a lightweight tool created specifically for players looking to 
optimize their character's performance (DPS, Tank, or Healer) using 
Artificial Intelligence (ChatGPT, Gemini, Claude, etc.).

By clicking the "Export Gear" button in-game, the addon automatically scans 
and generates a detailed report that includes:
  - Character information (Name, Race, Class, and Specialization).
  - YOUR GLYPHS (Equipped Major and Minor glyphs).
  - COMPLETE GLOBAL STATS (Base attributes, Melee, Ranged, Spell, and Defense/
    Survival including Hit, Crit, Expertise, etc.).
  - DETAILED EQUIPMENT LOG: Every equipped item with its stats, socketed gems, 
    enchants, and interactive item links.
  - AVAILABLE BAG GEAR: Scans rare or higher quality gear stored in your bags 
    so the AI can analyze potential upgrades or sidegrades.

The generated report includes a pre-formatted prompt at the top so you can 
simply copy the text, paste it to any AI of your choice, and ask:
  - Am I on the right track with my current gear and stats?
  - Are my Hit Rating or Expertise over-capped?
  - Are my gems and enchants optimal for my role?
  - Do I have any better pieces sitting in my bags?
  - Which priority items should I target in dungeons or raids to upgrade?


-------------------------------------------------------------------------------
2. INSTALLATION INSTRUCTIONS
-------------------------------------------------------------------------------
To install the addon from this .ZIP file, follow these simple steps:

Step 1: Extract this .ZIP file on your computer.
Step 2: Open your World of Warcraft 3.3.5a game folder.
Step 3: Navigate to the following path inside your game directory:
        WoW-3.3.5a/Interface/AddOns/

Step 4: Copy or drag the folder named "GearExport" directly into the "AddOns" folder.
        
        The final directory path should look like this:
        .../World of Warcraft/Interface/AddOns/GearExport/
          - GearExport.toc
          - GearExport.lua
          - LICENSE.txt
          - README.txt
          - CHANGELOG.txt

Step 5: Launch the game. On the character selection screen, click the "AddOns" 
        button at the bottom left and ensure "GearExport" is checked and 
        "Load out of date AddOns" is enabled.

-------------------------------------------------------------------------------
3. HOW TO USE THE ADDON IN-GAME
-------------------------------------------------------------------------------
1. Log in with your character.
2. You have three ways to access the exporter:
   a) A movable floating button on your screen ("Export Gear").
   b) A button on your Minimap (hover for tooltip or left-click to open).
   c) A button inside your Character Frame ("Exportar IA") at the top right.
3. Click any of the buttons (or type /gearexport or /ge in chat).
4. A window containing your full character report will open (showing v1.1.0 at the bottom-left).
5. Click inside the text box, press Ctrl + A (to select all), and Ctrl + C (to copy).
6. Go to your favorite AI Chat, press Ctrl + V (to paste), and send. You will receive an instant professional gear analysis!

Note: If you ever accidentally drag the floating button off-screen, type in chat:
      /gearexport button
This will reset and center the button on your screen.

===============================================================================
Copyright (C) 2026 Cobralive. All rights reserved.