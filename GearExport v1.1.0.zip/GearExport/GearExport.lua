-- GearExport v1.1.0 | Copyright (C) 2026 Cobralive. All rights reserved.
-- Ver LICENSE.txt para condiciones de uso y distribución.

-- ============================================================================
-- SISTEMA DE LOCALIZACIÓN (ESPAÑOL / INGLÉS)
-- ============================================================================
local clientLanguage = GetLocale()
local L = {}

if clientLanguage == "esES" or clientLanguage == "esMX" then
    -- Texto en Español
    L["SYSTEM_INSTRUCTION"] = "Eres un experto de élite en World of Warcraft: Wrath of the Lich King (3.3.5a). Tu función es analizar minuciosamente el estado de un personaje y su equipo optimizando el rendimiento para PvE o PvP según corresponda.\n\n" ..
    "REGLAS ESTRUCTURALES DE RESPUESTA (Sigue ESTRICTAMENTE este formato):\n\n" ..
    "1. TABLA COMPARATIVA DE ESTADÍSTICAS:\n" ..
    "   Genera una tabla en Markdown con las estadísticas clave según la especialización y rol actual (ej. Golpe, Pericia, Stat Principal, Crítico, Celeridad, Temple/Resilience) usando EXACTAMENTE estas columnas:\n" ..
    "   | Estadística | Valor Actual | Límite / Cap Recomendado | Estado y Diagnóstico |\n" ..
    "   - Usa únicamente los siguientes emojis para el diagnóstico:\n" ..
    "     🔴 Sobrecapeado/Malo\n" ..
    "     🟡 Aceptable/Límite\n" ..
    "     🟢 Correcto/Excelente\n" ..
    "     ⚠️ Advertencia\n\n" ..
    "2. GLIFOS Y TALENTOS:\n" ..
    "   - Evalúa si los glifos sublimes y menores equipados son los BIS (Best in Slot) para la rama de talentos/rol.\n" ..
    "   - Si un glifo es ineficiente o subóptimo, indica explícitamente cuál quitar y por cuál reemplazarlo.\n\n" ..
    "3. ANÁLISIS DE BOLSAS (EQUIPO ALTERNATIVO):\n" ..
    "   - REGLA DE FILTRADO POR ENFOQUE:\n" ..
    "     * Si el equipo actualmente equipado es PVE (Temple = 0 o muy bajo), IGNORA COMPLETAMENTE todas las piezas PVP (las que contengan 'Temple' o 'Resiliencia') que estén en las bolsas.\n" ..
    "     * Si el equipo actualmente equipado es PVP (Temple elevado), IGNORA COMPLETAMENTE todas las piezas PVE en las bolsas.\n" ..
    "   - Con las piezas válidas restantes, evalúa solo las que representen una mejora REAL de atributos sin romper bonos de conjunto críticos (ej. 2p/4p T10) ni empeorar caps ya alcanzados.\n\n" ..
    "4. PRÓXIMOS UPGRADES PRIORITARIOS:\n" ..
    "   - Identifica las 3 o 4 casillas equipadas con menor nivel de objeto o con estadísticas subóptimas.\n" ..
    "   - Recomienda ítems específicos para sustituirlas (indicando Nombre del Ítem, Jefe y Banda/Mazmorra donde se obtiene).\n\n" ..
    "---\n\n"

    L["INTRO_MSG"] = "Hola. Mi personaje se llama %s, soy %s %s con especialización en %s en el servidor Warmane (WoW WotLK 3.3.5a).\nA continuación te proporciono el resumen completo de mis estadísticas globales, glifos, equipo equipado y piezas disponibles en bolsas:\n\n"
    L["HEADER_CONFIG"] = "=== CONFIGURACIÓN DEL PERSONAJE: %s ===\n"
    L["SPEC_TEXT"] = "Especialización: %s\n\n"
    L["GLYPHS_MAJOR"] = "[Glifos Sublimes]\n"
    L["GLYPHS_MINOR"] = "[Glifos Menores]\n"
    L["NONE"] = "  (Ninguno)\n"
    L["HEADER_STATS"] = "=== ESTADÍSTICAS GLOBALES ===\n"
    L["STATS_BASE"] = "[Estadísticas Base]\n"
    L["STR"] = "  Fuerza: "
    L["AGI"] = "  Agilidad: "
    L["STA"] = "  Aguante: "
    L["INT"] = "  Intelecto: "
    L["SPI"] = "  Espíritu: "
    L["ARMOR"] = "  Armadura: "
    L["STATS_MELEE"] = "[Cuerpo a cuerpo]\n"
    L["DAMAGE"] = "  Daño: "
    L["ATTACK_SPEED"] = "  Velocidad de ataque: "
    L["ATTACK_POWER"] = "  Poder de ataque: "
    L["HIT_RATING"] = "  Índice de golpe: "
    L["CRIT_CHANCE"] = "  Probabilidad de crítico: "
    L["EXPERTISE"] = "  Pericia: "
    L["STATS_RANGED"] = "[A distancia]\n"
    L["RANGED_AP"] = "  Poder de ataque a distancia: "
    L["STATS_SPELL"] = "[Hechizos]\n"
    L["SPELL_POWER"] = "  Poder con hechizos: "
    L["HEALING"] = "  Sanación aumentada: "
    L["SPELL_HIT"] = "  Índice de golpe con hechizos: "
    L["SPELL_CRIT"] = "  Probabilidad de crítico con hechizos: "
    L["HASTE"] = "  Índice de celeridad con hechizos: "
    L["MANA_REGEN_OOC"] = "  Regeneración de maná (fuera de combate): "
    L["MANA_REGEN_COMBAT"] = "  Regeneración de maná (en combate): "
    L["STATS_DEFENSE"] = "[Defensa y Supervivencia]\n"
    L["DODGE"] = "  Esquiva: "
    L["PARRY"] = "  Parada: "
    L["BLOCK"] = "  Bloqueo: "
    L["DEFENSE"] = "  Índice de defensa: "
    L["RESILIENCE"] = "  Temple (Resiliencia): "
    L["HEADER_GEAR"] = "=== REGISTRO DE EQUIPO DETALLADO ===\n\n"
    L["HEADER_BAGS"] = "=== PIEZAS DE EQUIPO DISPONIBLES EN BOLSAS ===\n\n"
    L["INSTRUCTIONS"] = "Clic en el texto -> Presiona Ctrl + A -> Presiona Ctrl + C para copiar"
    L["BTN_ACCEPT"] = "Aceptar"
    L["BTN_CREDITS"] = "Créditos"
    L["BTN_EXPORT"] = "Exportar Equipo"
    L["SUCCESS_MSG"] = "|cffffd100[GearExport v1.1.0]|r ¡Datos del personaje generados con éxito!"
    L["CENTER_MSG"] = "|cffffd100[GearExport]|r El botón ha sido centrado en tu pantalla."
    L["CREDITS_CREATOR"] = "|cff00ff00Creador & Diseñador:|r\n"
    L["CREDITS_ROLE"] = "|cffffffffElfo de Sangre - Paladín Reprensión|r\n"
    L["CREDITS_SERVER"] = "|cff808080Servidor Warmane (WotLK 3.3.5a)|r\n\n"
    L["CREDITS_QUOTE"] = "|cffffd200\"Que la Luz guíe tu DPS y optimice tu equipo.\"|r\n\n"
    L["CREDITS_THANKS"] = "|cff00ccff¡Gracias por probar y usar esta herramienta!|r"
    L["UNKNOWN_TREE"] = "Desconocida"
else
    -- Default Text (English)
    L["SYSTEM_INSTRUCTION"] = "You are an elite expert in World of Warcraft: Wrath of the Lich King (3.3.5a). Your role is to analyze a character state and equipment to optimize performance for PvE or PvP accordingly.\n\n" ..
    "RESPONSE STRUCTURE RULES (STRICTLY follow this format):\n\n" ..
    "1. STAT COMPARISON TABLE:\n" ..
    "   Generate a Markdown table with key stats using EXACTLY these columns:\n" ..
    "   | Stat | Current Value | Cap / Recommended Cap | Status & Diagnosis |\n\n" ..
    "2. GLYPHS AND TALENTS:\n" ..
    "   - Evaluate if equipped major and minor glyphs are BIS.\n\n" ..
    "3. BAGS ANALYSIS (ALTERNATIVE GEAR):\n" ..
    "   - If equipped gear is PvE, ignore PvP gear in bags. If PvP, ignore PvE gear.\n\n" ..
    "4. PRIORITY UPGRADES:\n" ..
    "   - Identify 3-4 lowest slot items and suggest upgrades.\n\n" ..
    "---\n\n"

    L["INTRO_MSG"] = "Hello. My character's name is %s, I am a %s %s specializing in %s on the Warmane server (WoW WotLK 3.3.5a).\nBelow I provide the full summary of my global stats, glyphs, equipped gear, and available bag items:\n\n"
    L["HEADER_CONFIG"] = "=== CHARACTER CONFIGURATION: %s ===\n"
    L["SPEC_TEXT"] = "Specialization: %s\n\n"
    L["GLYPHS_MAJOR"] = "[Major Glyphs]\n"
    L["GLYPHS_MINOR"] = "[Minor Glyphs]\n"
    L["NONE"] = "  (None)\n"
    L["HEADER_STATS"] = "=== GLOBAL STATS ===\n"
    L["STATS_BASE"] = "[Base Stats]\n"
    L["STR"] = "  Strength: "
    L["AGI"] = "  Agility: "
    L["STA"] = "  Stamina: "
    L["INT"] = "  Intellect: "
    L["SPI"] = "  Spirit: "
    L["ARMOR"] = "  Armor: "
    L["STATS_MELEE"] = "[Melee]\n"
    L["DAMAGE"] = "  Damage: "
    L["ATTACK_SPEED"] = "  Attack Speed: "
    L["ATTACK_POWER"] = "  Attack Power: "
    L["HIT_RATING"] = "  Hit Rating: "
    L["CRIT_CHANCE"] = "  Crit Chance: "
    L["EXPERTISE"] = "  Expertise: "
    L["STATS_RANGED"] = "[Ranged]\n"
    L["RANGED_AP"] = "  Ranged Attack Power: "
    L["STATS_SPELL"] = "[Spells]\n"
    L["SPELL_POWER"] = "  Spell Power: "
    L["HEALING"] = "  Bonus Healing: "
    L["SPELL_HIT"] = "  Spell Hit Rating: "
    L["SPELL_CRIT"] = "  Spell Crit Chance: "
    L["HASTE"] = "  Spell Haste Rating: "
    L["MANA_REGEN_OOC"] = "  Mana Regen (out of combat): "
    L["MANA_REGEN_COMBAT"] = "  Mana Regen (in combat): "
    L["STATS_DEFENSE"] = "[Defense & Survival]\n"
    L["DODGE"] = "  Dodge: "
    L["PARRY"] = "  Parry: "
    L["BLOCK"] = "  Block: "
    L["DEFENSE"] = "  Defense Rating: "
    L["RESILIENCE"] = "  Resilience: "
    L["HEADER_GEAR"] = "=== DETAILED EQUIPMENT LOG ===\n\n"
    L["HEADER_BAGS"] = "=== AVAILABLE BAG GEAR ===\n\n"
    L["INSTRUCTIONS"] = "Click text -> Press Ctrl + A -> Press Ctrl + C to copy"
    L["BTN_ACCEPT"] = "Accept"
    L["BTN_CREDITS"] = "Credits"
    L["BTN_EXPORT"] = "Export Gear"
    L["SUCCESS_MSG"] = "|cffffd100[GearExport v1.1.0]|r Character data generated successfully!"
    L["CENTER_MSG"] = "|cffffd100[GearExport]|r Button centered on your screen."
    L["CREDITS_CREATOR"] = "|cff00ff00Creator & Designer:|r\n"
    L["CREDITS_ROLE"] = "|cffffffffBlood Elf - Retribution Paladin|r\n"
    L["CREDITS_SERVER"] = "|cff808080Warmane Server (WotLK 3.3.5a)|r\n\n"
    L["CREDITS_QUOTE"] = "|cffffd200\"May the Light guide your DPS and optimize your gear.\"|r\n\n"
    L["CREDITS_THANKS"] = "|cff00ccffThank you for testing and using this tool!|r"
    L["UNKNOWN_TREE"] = "Unknown"
end

-- ============================================================================
-- FUNCIONES DEL ADDON
-- ============================================================================

local function CleanLink(link)
    if not link then return "" end
    return link:gsub("|c%x%x%x%x%x%x%x%x%[", "["):gsub("%]|r", "]")
end

local function GetPrimaryTalentTree()
    local maxPoints = 0
    local mainTree = L["UNKNOWN_TREE"]
    for i = 1, GetNumTalentTabs() do
        local name, _, pointsSpent = GetTalentTabInfo(i)
        if pointsSpent and pointsSpent > maxPoints then
            maxPoints = pointsSpent
            mainTree = name
        end
    end
    return mainTree
end

local function GetGlyphsInfo()
    local text = L["GLYPHS_MAJOR"]
    local majorGlyphs = {}
    local minorGlyphs = {}
    
    pcall(function()
        for i = 1, 6 do
            local enabled, glyphType, spellID = GetGlyphSocketInfo(i)
            if enabled then
                local link = GetGlyphLink and GetGlyphLink(i)
                local name = nil
                
                if link then
                    name = link:match("%[(.+)%]")
                end
                if not name and spellID and spellID > 0 then
                    name = GetSpellInfo(spellID)
                end
                
                if name then
                    if glyphType == 1 or glyphType == GLYPH_MAJOR then
                        table.insert(majorGlyphs, "  - " .. name)
                    elseif glyphType == 2 or glyphType == GLYPH_MINOR then
                        table.insert(minorGlyphs, "  - " .. name)
                    end
                end
            end
        end
    end)
    
    if #majorGlyphs > 0 then
        text = text .. table.concat(majorGlyphs, "\n") .. "\n"
    else
        text = text .. L["NONE"]
    end
    
    text = text .. L["GLYPHS_MINOR"]
    if #minorGlyphs > 0 then
        text = text .. table.concat(minorGlyphs, "\n") .. "\n\n"
    else
        text = text .. L["NONE"] .. "\n"
    end
    
    return text
end

local function GetBagsGearInfo()
    local text = L["HEADER_BAGS"]
    local count = 0
    for bag = 0, 4 do
        local numSlots = GetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local link = GetContainerItemLink(bag, slot)
            if link then
                local _, _, quality, _, _, _, _, _, equipLoc = GetItemInfo(link)
                if quality and quality >= 3 and equipLoc and equipLoc ~= "" then
                    text = text .. string.format("[Bolsa %d / Casilla %d] %s\n", bag, slot, CleanLink(link))
                    count = count + 1
                end
            end
        end
    end
    if count == 0 then
        text = text .. L["NONE"] .. "\n"
    end
    return text .. "\n"
end

local function ShowCreditsWindow()
    if not GearExportCreditsFrame then
        local cf = CreateFrame("Frame", "GearExportCreditsFrame", UIParent, "DialogBoxFrame")
        cf:SetSize(420, 260)
        cf:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        cf:SetMovable(true)
        cf:EnableMouse(true)
        cf:RegisterForDrag("LeftButton")
        cf:SetScript("OnDragStart", cf.StartMoving)
        cf:SetScript("OnDragStop", cf.StopMovingOrSizing)

        local bg = cf:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints(cf)
        bg:SetTexture(0, 0, 0, 0.95)

        local title = cf:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", cf, "TOP", 0, -16)
        title:SetText("|cffffd100GearExport Addon v1.1.0|r")

        local creditsText = cf:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        creditsText:SetPoint("TOPLEFT", cf, "TOPLEFT", 20, -45)
        creditsText:SetPoint("BOTTOMRIGHT", cf, "BOTTOMRIGHT", -20, 50)
        creditsText:SetJustifyH("CENTER")
        creditsText:SetJustifyV("MIDDLE")
        
        local info = L["CREDITS_CREATOR"] .. "|cffff8000Cobralive|r\n"
        info = info .. L["CREDITS_ROLE"]
        info = info .. L["CREDITS_SERVER"]
        info = info .. L["CREDITS_QUOTE"]
        info = info .. L["CREDITS_THANKS"]

        creditsText:SetText(info)

        local dialogBtn = _G[cf:GetName() .. "Button"]
        if dialogBtn then
            dialogBtn:SetText(L["BTN_ACCEPT"])
        end
    end

    GearExportCreditsFrame:Show()
end

local function ExportGear()
    local pName = UnitName("player") or "Player"
    local pRace = UnitRace("player") or "Race"
    local pClass = UnitClass("player") or "Class"
    local pSpec = GetPrimaryTalentTree()

    local text = L["SYSTEM_INSTRUCTION"]
    text = text .. string.format(L["INTRO_MSG"], pName, pRace, pClass, pSpec)
    text = text .. string.format(L["HEADER_CONFIG"], string.upper(pName))
    text = text .. string.format(L["SPEC_TEXT"], pSpec)
    
    text = text .. GetGlyphsInfo()

    text = text .. L["HEADER_STATS"]
    
    local str = UnitStat("player", 1) or 0
    local agi = UnitStat("player", 2) or 0
    local sta = UnitStat("player", 3) or 0
    local int = UnitStat("player", 4) or 0
    local spi = UnitStat("player", 5) or 0
    local _, armor = UnitArmor("player")
    
    text = text .. L["STATS_BASE"]
    text = text .. L["STR"] .. str .. "\n"
    text = text .. L["AGI"] .. agi .. "\n"
    text = text .. L["STA"] .. sta .. "\n"
    text = text .. L["INT"] .. int .. "\n"
    text = text .. L["SPI"] .. spi .. "\n"
    text = text .. L["ARMOR"] .. (armor or 0) .. "\n\n"

    local baseAP, posBuff, negBuff = UnitAttackPower("player")
    local meleeAP = (baseAP or 0) + (posBuff or 0) + (negBuff or 0)
    local meleeCrit = GetCritChance() or 0
    local hitRating = GetCombatRating(CR_HIT_MELEE) or 0
    local hitPercent = GetCombatRatingBonus(CR_HIT_MELEE) or 0
    local expMain = GetExpertise() or 0
    local minDmg, maxDmg = UnitDamage("player")
    local speed = UnitAttackSpeed("player") or 0

    text = text .. L["STATS_MELEE"]
    text = text .. L["DAMAGE"] .. math.floor(minDmg or 0) .. " - " .. math.ceil(maxDmg or 0) .. "\n"
    text = text .. L["ATTACK_SPEED"] .. string.format("%.2f", speed) .. "\n"
    text = text .. L["ATTACK_POWER"] .. meleeAP .. "\n"
    text = text .. L["HIT_RATING"] .. hitRating .. " (" .. string.format("%.2f", hitPercent) .. "%)\n"
    text = text .. L["CRIT_CHANCE"] .. string.format("%.2f", meleeCrit) .. "%\n"
    text = text .. L["EXPERTISE"] .. expMain .. "\n\n"

    local rBaseAP, rPosBuff, rNegBuff = UnitRangedAttackPower("player")
    local rangedAP = (rBaseAP or 0) + (rPosBuff or 0) + (rNegBuff or 0)
    local rangedCrit = GetRangedCritChance() or 0
    local rangedHitRating = GetCombatRating(CR_HIT_RANGED) or 0
    local rangedHitPercent = GetCombatRatingBonus(CR_HIT_RANGED) or 0

    text = text .. L["STATS_RANGED"]
    text = text .. L["RANGED_AP"] .. rangedAP .. "\n"
    text = text .. L["HIT_RATING"] .. rangedHitRating .. " (" .. string.format("%.2f", rangedHitPercent) .. "%)\n"
    text = text .. L["CRIT_CHANCE"] .. string.format("%.2f", rangedCrit) .. "%\n\n"

    local spellBonusDamage = 0
    for i = 2, 7 do
        local dmg = GetSpellBonusDamage(i) or 0
        if dmg > spellBonusDamage then
            spellBonusDamage = dmg
        end
    end
    local spellBonusHealing = GetSpellBonusHealing() or 0
    local spellHitRating = GetCombatRating(CR_HIT_SPELL) or 0
    local spellHitPercent = GetCombatRatingBonus(CR_HIT_SPELL) or 0
    local spellCrit = GetSpellCritChance(2) or 0
    local spellHaste = GetCombatRating(CR_HASTE_SPELL) or 0
    local manaRegenBase, manaRegenCasting = GetManaRegen()

    text = text .. L["STATS_SPELL"]
    text = text .. L["SPELL_POWER"] .. spellBonusDamage .. "\n"
    text = text .. L["HEALING"] .. spellBonusHealing .. "\n"
    text = text .. L["SPELL_HIT"] .. spellHitRating .. " (" .. string.format("%.2f", spellHitPercent) .. "%)\n"
    text = text .. L["SPELL_CRIT"] .. string.format("%.2f", spellCrit) .. "%\n"
    text = text .. L["HASTE"] .. spellHaste .. "\n"
    text = text .. L["MANA_REGEN_OOC"] .. math.floor((manaRegenBase or 0) * 5) .. " / 5s\n"
    text = text .. L["MANA_REGEN_COMBAT"] .. math.floor((manaRegenCasting or 0) * 5) .. " / 5s\n\n"

    local dodgeChance = GetDodgeChance() or 0
    local parryChance = GetParryChance() or 0
    local blockChance = GetBlockChance() or 0
    local defenseRating = GetCombatRating(CR_DEFENSE_SKILL) or 0
    local resilienceRating = GetCombatRating(CR_CRIT_TAKEN_MELEE) or 0

    text = text .. L["STATS_DEFENSE"]
    text = text .. L["DODGE"] .. string.format("%.2f", dodgeChance) .. "%\n"
    text = text .. L["PARRY"] .. string.format("%.2f", parryChance) .. "%\n"
    text = text .. L["BLOCK"] .. string.format("%.2f", blockChance) .. "%\n"
    text = text .. L["DEFENSE"] .. defenseRating .. "\n"
    text = text .. L["RESILIENCE"] .. resilienceRating .. "\n\n"

    text = text .. L["HEADER_GEAR"]

    local tooltip = CreateFrame("GameTooltip", "GearExportScanner", nil, "GameTooltipTemplate")
    tooltip:SetOwner(WorldFrame, "ANCHOR_NONE")

    for slot = 1, 19 do
        local link = GetInventoryItemLink("player", slot)
        if link then
            tooltip:ClearLines()
            tooltip:SetInventoryItem("player", slot)
            text = text .. "[" .. slot .. "] " .. link .. "\n"
            for line = 1, tooltip:NumLines() do
                local leftText = _G["GearExportScannerTextLeft" .. line]
                if leftText and leftText:GetText() then
                    text = text .. "  " .. leftText:GetText() .. "\n"
                end
            end
            text = text .. "\n"
        end
    end

    -- Añadir escaneo de piezas en bolsas
    text = text .. GetBagsGearInfo()

    if not GearExportFrame then
        local f = CreateFrame("Frame", "GearExportFrame", UIParent, "DialogBoxFrame")
        f:SetSize(600, 470)
        f:SetPoint("CENTER")
        f:SetMovable(true)
        f:EnableMouse(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)

        local instructions = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        instructions:SetPoint("TOP", f, "TOP", 0, -12)
        instructions:SetText(L["INSTRUCTIONS"])
        instructions:SetTextColor(1, 0.82, 0)

        local sf = CreateFrame("ScrollFrame", "GearExportScroll", f, "UIPanelScrollFrameTemplate")
        sf:SetPoint("TOPLEFT", 15, -30)
        sf:SetPoint("BOTTOMRIGHT", -35, 55)

        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true)
        eb:SetMaxLetters(99999)
        eb:EnableMouse(true)
        eb:SetAutoFocus(true)
        eb:SetFontObject(ChatFontNormal)
        eb:SetWidth(520)
        sf:SetScrollChild(eb)
        f.editBox = eb

        -- Texto de versión en la esquina inferior izquierda
        local versionText = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        versionText:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 20, 20)
        versionText:SetText("v1.1.0")

        local acceptBtn = _G[f:GetName() .. "Button"]
        if acceptBtn then
            acceptBtn:SetText(L["BTN_ACCEPT"])
            acceptBtn:ClearAllPoints()
            acceptBtn:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -20, 16)
        end

        local creditsBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        creditsBtn:SetSize(120, 24)
        creditsBtn:SetPoint("RIGHT", acceptBtn, "LEFT", -10, 0)
        creditsBtn:SetText(L["BTN_CREDITS"])
        creditsBtn:SetScript("OnClick", function()
            ShowCreditsWindow()
        end)
    end

    GearExportFrame.editBox:SetText(text)
    GearExportFrame.editBox:HighlightText()
    GearExportFrame:Show()

    DEFAULT_CHAT_FRAME:AddMessage(L["SUCCESS_MSG"])
end

-- ============================================================================
-- CREACIÓN DEL BOTÓN FLOTANTE INDEPENDIENTE
-- ============================================================================

local function CreateExportButton()
    if not GearExportStandaloneBtn then
        local btn = CreateFrame("Button", "GearExportStandaloneBtn", UIParent, "UIPanelButtonTemplate")
        btn:SetSize(130, 26)
        btn:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
        btn:SetText(L["BTN_EXPORT"])
        btn:SetMovable(true)
        btn:EnableMouse(true)
        btn:RegisterForDrag("LeftButton")
        btn:SetScript("OnDragStart", btn.StartMoving)
        btn:SetScript("OnDragStop", btn.StopMovingOrSizing)
        btn:SetScript("OnClick", ExportGear)
    end
    GearExportStandaloneBtn:Show()
end

-- Inicialización del Addon
local eventHandler = CreateFrame("Frame")
eventHandler:RegisterEvent("PLAYER_ENTERING_WORLD")
eventHandler:SetScript("OnEvent", function(self, event)
    CreateExportButton()
end)

SLASH_GEAREXPORT1 = "/gearexport"
SLASH_GEAREXPORT2 = "/ge"
SlashCmdList["GEAREXPORT"] = function(msg)
    if msg and msg:lower() == "button" then
        if GearExportStandaloneBtn then
            GearExportStandaloneBtn:ClearAllPoints()
            GearExportStandaloneBtn:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
            GearExportStandaloneBtn:Show()
            DEFAULT_CHAT_FRAME:AddMessage(L["CENTER_MSG"])
        end
    else
        ExportGear()
    end
end